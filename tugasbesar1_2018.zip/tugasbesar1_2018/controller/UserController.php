<?php
/**
 * Created by PhpStorm.
 * User: Gery Wahyu
 * Date: 10/15/2018
 * Time: 4:48 PM
 */

class UserController
{
    public static function create(Request $request) {
        // TODO: Register a user
        return "Error";
    }
}