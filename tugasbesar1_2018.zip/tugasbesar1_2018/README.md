# Tugas 1 IF3110 Pengembangan Aplikasi Berbasis Web

Membuat sebuah Website Toko Buku
## Deskripsi Singkat

Pada tugas besar ini, Kami diminta untuk membuat aplikasi *toko buku online* **berbasis web** yang memungkinkan seorang pengguna untuk membeli dan memberi komentar pada buku. Untuk menggunakan aplikasi ini, seorang pengguna harus melakukan *login*. 

Kami diminta untuk membuat tampilan sedemikian hingga mirip dengan tampilan pada contoh. Website yang diminta tidak responsive. Desain tampilan tidak perlu dibuat indah. Icon dan jenis font tidak harus sama dengan contoh. Warna font, garis pemisah, dan perbedaan ukuran font harus terlihat sesuai contoh. Format rating dan waktu harus terlihat sesuai contoh.

## Anggota Tim
1. Albert Sahala Theodore - 13516022 <br>
2. I Putu Eka Surya Aditya - 13516061 <br>
3. Putu Gery Wahyu Nugraha - 13516100 <br>
4. Hagai Raja Sinulingga - 13516136 <br>

## Desain Basis Data 
### Entity Relation Diagram (ERD)
Setelah melihat spesifikasi tugas, kami memulai bagian mendesain bagian back-end dimulai dari database-nya. 
Berikut adalah ERD hasil diskusi kami.
![](img/ERD.jpg "Database ERD")

### Cara Import Basis Data
Buat database bernama `probookdb` lalu lakukan import menggunakan file `database.sql` pada folder database dengan mematikan constraint checker saat melakukan import.

## Cara Menjalankan Aplikasi
Pada terminal ketik php -S localhost:<port> dan pada browser cukup diketikkan localhost:<port>.
## Tampilan Aplikasi

### Login

![](mocks/Our-Mock/login.JPG)

Pengguna dapat melakukan login sebagai user. Login hanya membandingkan username dan password saja, dan tidak perlu proteksi apapun. Identitas pengguna yang sudah login akan disimpan sebagai cookie dalam browser (misal cookie menyimpan id=2 menandakan bahwa pengguna dengan id 2 sudah login). Identitas tersebut tidak boleh disimpan sebagai parameter HTTP GET. Jika cookie ini tidak ada, maka pengguna dianggap belum login dan aplikasi akan selalu mengarahkan (*redirect*) pengguna ke halaman ini, meskipun pengguna membuka halaman yang lain. Masa berlaku cookie ditentukan sendiri oleh peserta.

Kami mengerjakan bonus sehingga data yang disimpan pada cookie berupa **access token** yang dibangkitkan secara random dan memiliki **expiry time** . Jika **access token** ini tidak ada atau tidak valid, maka pengguna dianggap belum login. **Expiry time** sebuah **access token**` berbeda dengan waktu berlaku cookie.

### Register

![](mocks/Our-Mock/verikasi%20-%20register.JPG)

Pengguna dapat mendaftarkan diri sebagai user agar dapat menggunakan aplikasi ini. Pengguna tidak dapat mendaftarkan diri menggunakan email dan/atau username yang sudah pernah digunakan sebelumnya. Jika email dan username valid akan ditandai dengan lambang centang seperti pada gambar. Setelah mendaftarkan diri, pengguna akan secara otomatis login dengan user yang baru didaftarkannya.

### Search-Books

![](mocks/Our-Mock/search.JPG)

Search-Books merupakan halaman utama yang ditampilkan ketika user telah login. Pada halaman Search-Books, terdapat sebuah input field dapat diisi pengguna untuk melakukan pencarian buku berdasarkan judul.

Setelah pengguna menekan tombol search, pengguna akan dibawa ke halaman Search-Result.

Perlu diperhatikan, pada bagian atas terdapat logo, tombol logout, dan tulisan dengan format "Hi, username". Selanjutnya, terdapat menu bar yang menampilkan 3 menu utama seperti pada gambar. Menu yang sedang dibuka diberikan warna background yang berbeda sebagai penanda halaman apa yang sedang dibuka pengguna.

### Search-Result

![](mocks/Our-Mock/search%20result.JPG)

Pada Search-Result, ditampilkan daftar buku dan jumlah hasil pencarian. Pada tiap entri buku ditampilkan judul, penulis, gambar, potongan sinopsis, serta rating dari buku tersebut. Jika tombol detail ditekan, pengguna akan dibawa ke halaman Book-Detail dari buku yang bersangkutan.

### Book-Detail

![](mocks/Our-Mock/book%20detail.JPG)

Pada halaman ini, ditampilkan detail buku yang terdiri dari judul, penulis, gambar, rating, serta komentar dan rating dari user lain.

Pada halaman ini juga disediakan dropdown untuk memasukkan jumlah buku yang ingin dipesan dan tombol order. Jika tombol order ditekan, proses pemesanan akan dilakukan **menggunakan AJAX**, yang berarti halaman tidak akan di-*refresh* setelah tombol order ditekan. Tidak ada proses pembayaran yang ditangani oleh sistem.

![](mocks/Our-Mock/transaction%20success.JPG)

Setelah proses pemesanan selesai dilakukan, akan muncul notifikasi pada browser pengguna. **Jangan menampilkan notifikasi setelah tombol order ditekan, tetapi setelah mendapat response dari AJAX**. Informasi yang diberikan oleh notifikasi mengikuti contoh.

### Profile

![](mocks/Our-Mock/profile update.JPG)

Pada halaman ini, ditampilkan nama lengkap, username, email, alamat, nomor telepon, dan foto profil. Pada bagian kanan atas terdapat tombol edit, jika pengguna menekan tombol tersebut, pengguna dibawa ke halaman Edit-Profile.

### Edit-Profile

![](mocks/Our-Mock/edit%20profile.JPG)

Pada halaman ini, pengguna dapat mengubah nama yang ditampilkan, alamat, nomor telepon, dan foto profil.

Pada bagian bawah halaman, terdapat tombol Back dan Save. Jika tombol Back ditekan, pengguna kembali ke halaman Profile tanpa mengubah informasi profilnya. Jika tombol save ditekan, nama dan alamat pengguna akan diganti sesuai input field, dan pengguna dibawa ke halaman Profile.

### History

![](mocks/Our-Mock/history.JPG)

Pada halaman ini, ditampilkan daftar buku yang sudah pernah dipesan oleh pengguna, diurutkan berdasarkan waktu pemesanan dengan pesanan paling baru merupakan entri paling atas.

Pada tiap entri pada history, terdapat tombol review. Jika tombol review ditekan, pengguna akan dibawa ke halaman Review. Jika pengguna sudah memberikan review untuk order tersebut, tombol review akan hilang dari entri yang bersangkutan.

### Review

![](mocks/Our-Mock/review.JPG)

Pada halaman ini, pengguna dapat memberikan review untuk buku yang dipesan berupa rating dan komentar. Review yang diberikan dari halaman ini akan muncul pada halaman Book-Detail dari buku yang di-review. Setelah selesai, user akan dibawa kembali ke halaman History.

Kami mengerjakan bonus sehingga pemberian rating seperti pada contoh spesifikasi.

### Review-Submitted

![](mocks/Our-Mock/review submitted.JPG)
Pada halaman ini ditampilkan hasil review dari pengguna.

### Pembagian Tugas

**Tampilan**
1. Login : 13516022
2. Register : 13516061,13516100
3. Search-Books : 13516061
4. Search-Result : 13516061, 13516100
5. Book-Detail : 13516061
6. Profile : 13516022
7. Edit-Profile : 13516022
8. History : 13516022
9. Review : 13516022,13516136,13516061
10. Navbar : 13516061,13516136,13516100 

**Fungsionalitas**
1. Login : 13516136, 13516022
2. Register : 13516136,13516061
3. Search-Book : 13516136,13516100
4. Search-Result : 13516136
5. Book-Detail : 13516136, 13516061
6. Profile : 13516136,13516022
7. Edit-Profile : 13516136
8. History : 13516136,13516100
9. Review : 13516136
10. Navbar : 13516136,13516061 



